"""SecureWatch collectors package."""
