"""SecureWatch monitors package."""
